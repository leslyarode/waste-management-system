
    <!-- Bootstrap core JavaScript-->
    <script src="{{Asset('Assets/vendor/jquery/jquery.min.js')}}"></script>
    <script src="{{Asset('Assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{Asset('Assets/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{Asset('Assets/js/sb-admin-2.min.js')}}"></script>