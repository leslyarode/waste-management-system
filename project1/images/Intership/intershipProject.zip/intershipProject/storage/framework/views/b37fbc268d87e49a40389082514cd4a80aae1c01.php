
<!doctype html>
<html>
<head>
   <?php echo $__env->make('client.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="bg-gradient-secondary">

    <div class="container">

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <div class="card shadow mb-4">
    </div>
    <?php echo $__env->make('client.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\HP\Desktop\Intership\intershipProject\resources\views/client/layout/layout.blade.php ENDPATH**/ ?>