
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(Asset('Assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(Asset('Assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(Asset('Assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(Asset('Assets/js/sb-admin-2.min.js')); ?>"></script><?php /**PATH C:\Users\HP\Desktop\Intership\intershipProject\resources\views/client/layout/footer.blade.php ENDPATH**/ ?>