
<!doctype html>
<html>
<head>
   <?php echo $__env->make('client.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body id="page-top">

    

        <!-- Page Wrapper -->
        <div id="wrapper">
        <?php echo $__env->make('Dashboard.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->yieldContent('content'); ?>

        </div>
    
    <?php echo $__env->make('Dashboard.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\Users\HP\Desktop\Intership\intershipProject\resources\views/Dashboard/layout/layout.blade.php ENDPATH**/ ?>